# Python hw1

Write a simple program that finds the solutions of the quadratic equation. When writing your code, keep in mind that there may be no solutions. (You can reuse this part of code from internet).

The program asks for variables a, b and c and returns the solutions x1 and x2.
